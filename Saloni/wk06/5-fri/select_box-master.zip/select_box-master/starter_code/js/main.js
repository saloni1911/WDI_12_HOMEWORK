var cities = [];
