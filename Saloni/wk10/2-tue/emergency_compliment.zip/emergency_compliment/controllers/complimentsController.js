var complimentsController = {
	new: function(req, res) {
	  res.render('addcompliment');
	}
};

module.exports = complimentsController;